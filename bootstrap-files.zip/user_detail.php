<?php
session_start();
include("conn.php");
include("func.php");
// farr($_SESSION);
// die();
islogin();
?>

<!Doctype html>
<html>
<head>
	<title>User Details</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="css/css.css">
	<link rel="stylesheet" href="bootstrap-files/bootstrap.min.css">
	<link rel="stylesheet" href="bootstrap-files/bootstrap-theme.min.css">
	<link href="bootstrap-files/bootstrap-glyphicons.css" rel="stylesheet">
	<script type="text/javascript" src="bootstrap-files/jquery-3.1.0.min.js"></script>
	<script src="bootstrap-files/bootstrap.min.js"></script>
	<script src="myjs.js"></script>
	<style>
	</style>
</head>
<body>
	<div class="container-fluid" style="background-color:black;">
		<div class="row">
			<div class="col-sm-12">
				<p id="cch1" style="color:white;">Welcome to Admin Dashboard</p>
			</div>
		</div>
	</div>
	
	<div class="container-fluid" style="background-color:#ee6e73;color:white;font-size:18px;">
		<div class="row">
				<div class="col-sm-4 hidden-xs">
					<div class="setpadding"></div>
					<span id="font-text" style="font-size:18px;color:white;"><a href="user_detail.php">Admin Panel</a></span>
					<div class="setpadding hidden-xs"></div>
				</div>
				<div class="col-sm-4 visible-xs">
					<div class="setpadding"></div>
					<p class="text-center"><span id="font-text" style="font-size:24px;"><a href="user_detail.php">Admin Panel</a></span></p>
					<div class="setpadding hidden-xs"></div>
				</div>
				<div class="col-sm-8">
					<div class="row">
						<div class="col-xs-6">
							<div class="setpadding"></div>
							<span id="font-text" style="font-size:18px;"><a class="btn btn-warning" href="user_detail.php" style="color:white;">User Details</a></span>
							<div class="setpadding"></div>
						</div>
						<div class="col-xs-6">
							<div class="setpadding"></div>
							<span id="font-text" style="font-size:18px;"><a class="btn btn-warning" href="http://getfreedash.com/login.php?logout" style="color:white;">Log Out</a></span>
							<div class="setpadding"></div>
						</div>
					</div>
				</div>
		</div>
	</div>
		
	<div class="container">
		<div class="row">
			<div class="col-sm-offset-4 col-sm-4">
				<h3 class="text-center" id="font-text"><div class='bg-success text-center' style='border-radius:20px;font-size:16px;padding:10px 10px;'>User Details</div></h3>
			</div>
		</div>
	
	<?php
		$mq		=	mysql_query("SELECT * FROM gfd_user WHERE verified='1'");
		echo '  <div class="table-responsive">
		<table class="table table-striped">
    <thead>
      <tr>
        <th>Full Name</th>
        <th>Mobile Number</th>
        <th>Date & Time</th>
        <th>Wallet</th>
        <th>SignUp Bonus Given</th>
        <th>Referred Details</th>
      </tr>
    </thead>
    <tbody>
		';
		while($row=mysql_fetch_array($mq)){
			$id		=	$row['id'];
			$fname	=	$row['fname'];
			$lname	=	$row['lname'];
			$ref_by	=	$row['ref_by'];
			$id		=	$row['id'];
			$mob	=	$row['mobile'];
			$date	=	(int)$row['date'];
			$date_show	=	date('d-m-Y',$date);
			$time	=	date('h:i A',$date);
			$wallet	=	$row['wallet'];
			$signBonus	=	$row['signup_bonus_given'];
			// $refBonus	=	$row['referred_bonus_given'];
			
			$name = "$fname $lname";
			$signupbonus = $signBonus==1?"Yes":"<button class='btn btn-warning btn-sm giveSignBonus' value='$id'>No</button>";
			
			// if(empty($ref_by)){
				// $referralbonus = "Not required";
			// }
			// else{//check if ref bonus given
				// $referralbonus = $refBonus==1?"Yes":"<button class='btn btn-warning btn-sm giveRefBonus' value='$id --- $ref_by'>No</button>";
			// }
			
			echo"<tr>
			<td>$fname</td>
			<td>$mob</td>
			<td>$date_show $time</td>
			<td>$wallet</td>
			<td>$signupbonus</td>
			<td><a class='btn btn-primary' href='ref_track.php?id=$id'>Click Here</a></td>
			</tr>";
		}
		echo '</tbody>
		</table>
		</div>';
	?>
</div>
</body>
</html>
