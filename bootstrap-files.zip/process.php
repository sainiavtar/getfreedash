<?php
// phpinfo();
// echo $refby		=	$_SESSION["refby"];
// die();

session_start();
include("conn.php");
include("func.php");
// islogin();

// echo 111111111;
//default value
$data = array();
$error = 0;
$msg = '';
$proType = $_REQUEST['proType'];
// $proType = "steprefno";
//below to restrict any request from other host

$httpRef = @$_SERVER['HTTP_REFERER'];

// if(!strstr($httpRef, $httpRef))
// {
// $error=1;
// $msg="Invalid Site Access!!!";
// $result_array = array('error' => $error, 'msg' => $msg, 'data' => $data);
// echo json_encode($result_array);
// exit;
// }



//mow start processing $proType is there

$sayErr		=	"<div class='bg-danger text-center' style='border-radius:20px;font-size:16px;'>[[say]]</div>";
$saySuccess	=	"<div class='bg-success text-center' style='border-radius:20px;font-size:16px;'>[[saySuccess]]</div>";


if($proType=="stepfirst"){
	$ccode		=	$_GET['ccode'];
	$mob		=	$_GET['mob'];
	//remove initial zero
	$mob		= ltrim($mob,0);
	$full_mob	=	$ccode.$mob;
	$date		=	time();
	$refby		=	$_SESSION["refby"];
	$signupbonusgiven	=	0;
	$referredbonusgiven	=	0;
	$verify		=	0;
	$wallet		=	"";
	$say	=	"OTP is send on your mobile. Please verify!";
	if(strlen($mob)>8 && strlen($mob)<13 && is_numeric($mob)){
		$search_mob	=	rod("mobile","gfd_user","mobile='$mob' AND c_code='$ccode'");
		if(!empty($search_mob)){
			$is_verified	=	rod("verified","gfd_user","mobile='$mob' AND c_code='$ccode'");
			if($is_verified==1){
				$error = 1;
				$say	=	"Mobile number already exists!";
				$msg	=	str_replace("[[say]]",$say,$sayErr);
			}
			else{
					// echo "o55555555oo";die();
				sendotp("exist");
				$msg	=	str_replace("[[saySuccess]]",$say,$saySuccess);
			}
		}
		else{
				// echo "o44oo";die();
			sendotp();
			$msg	=	str_replace("[[saySuccess]]",$say,$saySuccess);
		}
	}
	else{
		// echo $serErr;
		
		$error = 1;
		$say	=	"Please select country code and enter mobile number correctly!";
		$msg	=	str_replace("[[say]]",$say,$sayErr);
	}
	

}

if($proType=="stepsecond"){
	$otp		=	$_GET['otp'];
	$fullmob	=	$_SESSION["fullmob"];//user mob
	$url = "http://api.msg91.com/api/verifyRequestOTP.php";
	$para = "authkey=140905AioSt4wtTj5589d989a&mobile=$fullmob&otp=$otp";
	$result = curldata($url,$para,1);
	$toJson = json_decode($result);
	// var_dump($toJson);
	$status = $toJson->message;
	// var_dump($status);
	if($status=="otp_verified"){
		$id	=	@$_SESSION["uid"];
		$upd	=	upd("gfd_user","verified=1","id='$id'");
		$error = 0;
		$say	=	"Mobile number verified successfully!";
		$msg	=	str_replace("[[saySuccess]]",$say,$saySuccess);
	}
	else{
		$error = 1;
		$say	=	"OTP Mismatch! Try again";
		$msg	=	str_replace("[[say]]",$say,$sayErr);	
	}
}

if($proType=="stepthird"){
	$wallet		=	$_GET['wallet'];
	if($wallet!=""){
		$id	=	$_SESSION["uid"];
		$upd	=	upd("gfd_user","wallet='$wallet'","id='$id'");
		$error = 0;
		$say	=	"Congratulation! Sign Up Successful!!!";
		$msg	=	str_replace("[[saySuccess]]",$say,$saySuccess);
	}
	else{
		$error = 1;
		$say	=	"Please enter wallet address!";
		$msg	=	str_replace("[[say]]",$say,$sayErr);	
	}
}

if($proType=="steprefno"){
	$refno		=	$_GET['refno'];
	if(strlen($refno)>8 && strlen($refno)<13 && is_numeric($refno)){
		$id		=	rod("id","gfd_user","mobile='$refno'");
		if($id==0){
			$error = 1;
			$say	=	"Mobile number not found!";
			$msg	=	str_replace("[[say]]",$say,$sayErr);

		}
		else{
			$id		=	base64_encode($id);
			$link		=	"http://getfreedash.com/index.php";
			$error	= 0;
			$say	=	$link."?id='$id'";
			$msg	=	str_replace("[[saySuccess]]",$say,$saySuccess);		
		}
	}
	else{
			$error = 1;
			$say	=	"Mobile number not found!";
			$msg	=	str_replace("[[say]]",$say,$sayErr);
	}
}

//ask for fname,lname and email when click on get ref link

if($proType=="askDetailPro"){
	$fname		=	@$_GET['fname'];
	$lname		=	@$_GET['lname'];
	$emailid	=	@$_GET['emailid'];
	// farr($_GET);die();
	//now insert in db
	$uid		=	@$_SESSION['uid'];
	if(empty($uid)){die("no uid in sess");}
	upd("gfd_user","fname='$fname',lname='$lname',email='$emailid'","id=$uid");
	$uData		=	rad("*","gfd_user","id=$uid");
	$error = 0;
	$msg = "";
	$data['result'] = showRefLink($uid,$uData);
}


//showReferralModal
if($proType=="showReferralModal"){
	$uid		=	@$_SESSION['uid'];
	$uData		=	rad("*","gfd_user","id=$uid");
	if(empty($uData)){//do nothing and exit;
	die("no data");
	}
	//otherwise
	
	if(!empty($uData['fname'])){//then directly show referral link and refid
		$error = 0;
		$msg = "";
		$data['result'] = showRefLink($uid,$uData);
	}
	else{//then ask for fname,lname and emailid
		ob_start();
		?>
			<!-- Referral modal-->
			<div id="askDetailModal" class="modal fade" role="dialog" data-backdrop="static" data-keyboard="false">
			  <div class="modal-dialog">

				<!-- Modal content-->
				<div class="modal-content">
				 
				  <div class="modal-body">
					<div id="msg4"></div>
					<h3>Generate Referral Link</h3><br>
					<p>We will send you email when any one sign up through your link.</p>
					<div class="container-fluid" style="background-color:#e6e6e6;margin-top:40px;padding-top:10px;">
					
						<div class="setpadding"></div>
						<div class="form-group">
						  <input name="fname" type="text" class="form-control" id="fname" placeholder="Enter First Name">
						</div>
						<div class="form-group">
						  <input name="lname" type="text" class="form-control" id="lname" placeholder="Enter Last Name">
						</div>
						<div class="form-group">
						  <input name="emailid" type="text" class="form-control" id="emailid" placeholder="Enter Email ID">
						</div>
						<button type="button" class="btn btn-success btn-lg askDetailPro">Next</button>
						<button class="btn btn-danger btn-lg" type="button" data-dismiss="modal">Close</button>
						<div class="setpadding"></div>
				  
					</div>
				  </div>
				</div>

			  </div>
			</div>
			<!-- Modal End-->
		<?php
		$error = 0;
		$msg = "nofname";
		$data['result'] = ob_get_clean();
		}
}

//pro giveSignBonus
if($proType=="giveSignBonus"){
	if(islogin(0)==0){
		// echo "Error";die();
	}
	$id		=	@$_GET['id'];
	$upd = upd("gfd_user","signup_bonus_given='1'","id='$id'");
	echo $upd==1?"Yes":"No";
	die();
}

//pro giveRefBonus
if($proType=="giveRefBonus"){
	if(islogin(0)==0){
		// echo "Error";die();
	}
	$getVal		=	@$_GET['getVal'];
	$explode	=	explode(" --- ",$getVal);
	$uid		=	$explode[0];
	$ref_by		=	$explode[1];
	
	$upd = upd("gfd_user","referred_bonus_given='1'","id='$uid'");
	echo $upd==1?"Yes":"No";
	die();
}


//now send json data
$result_array = array('error' => $error, 'msg' => $msg, 'data' => $data);
echo json_encode($result_array);
exit;
?>
